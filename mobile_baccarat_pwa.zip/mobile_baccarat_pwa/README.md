# Mobile Baccarat PWA

This is an iPhone-friendly Progressive Web App package.

## Important
Do not open `index.html` directly from the iPhone Files app. iOS treats local HTML files as restricted local files, so taps/audio/service worker features may fail.

## Best way to use on iPhone
1. Upload this folder to any HTTPS host:
   - GitHub Pages
   - Netlify
   - Cloudflare Pages
   - Vercel static hosting
2. Open the hosted URL in Safari on iPhone.
3. Tap Share → Add to Home Screen.
4. Launch it from the Home Screen like a mini app.

## Local testing
On your computer:
```bash
cd mobile_baccarat_pwa
python3 -m http.server 8000
```
Then visit `http://localhost:8000`.
